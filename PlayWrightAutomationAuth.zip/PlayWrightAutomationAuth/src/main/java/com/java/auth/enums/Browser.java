package com.java.auth.enums;

/**
 *
 */
public enum Browser {
    /**
     *
     */
    CHROME, EDGE, FIREFOX
}
